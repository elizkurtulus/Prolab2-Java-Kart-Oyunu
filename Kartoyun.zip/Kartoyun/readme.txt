Eliz Kurtluş
190202015

İrem Çelikkanat
190202124

Giris classından Run butonuna basarak çalıştırınız.